public interface NewsChannel {
    void update(String news);
}
